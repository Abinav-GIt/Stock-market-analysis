import yfinance as yf

def get_stock_data(ticker_symbol):
    stock = yf.Ticker(ticker_symbol)
    data = stock.history(period="1d")
    if data.empty:
        print("No data found for the ticker symbol.")
        return
    print(f"Stock: {ticker_symbol.upper()}")
    print(f"Current Price: {stock.info['currentPrice']}")
    print(f"Previous Close: {stock.info['previousClose']}")
    print(f"Today's Open: {stock.info['open']}")

if __name__ == "__main__":
    symbol = input("Enter the stock ticker symbol (e.g., AAPL, TSLA): ")
    get_stock_data(symbol)