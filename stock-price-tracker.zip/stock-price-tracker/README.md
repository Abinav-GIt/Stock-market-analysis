# Stock Price Tracker

This is a simple Python project to fetch and display real-time stock prices using the `yfinance` package.

## Features

- Real-time stock price data
- User input for any stock ticker
- Shows current price, previous close, and today's open

## How to Run

1. Install required package:
```
pip install yfinance
```

2. Run the script:
```
python stock_tracker.py
```

3. Enter a stock ticker like `AAPL` or `GOOGL`.

Enjoy!